package com.bapseguen.app.sellerMyPage;

public class OriginDeleteOkController {

}
