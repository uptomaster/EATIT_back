package com.bapseguen.app.sellerMyPage;

public class AlreadyOriginOkController {

}
