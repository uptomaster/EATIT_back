window.addEventListener('DOMContentLoaded', () => {
  // 각 파일마다 경로가 다르므로 경로 설정 후 진행하는 방식으로 작성함
  if (typeof footerPath === 'undefined') {
    console.error('footerPath 변수가 설정되지 않았습니다.');
    return;
  }
});
