package com.bapseguen.app.dto.view;

public class MyPage {
	
	private int memberNumber;
	private String memberId;
	private String memberPassword;
	private String generalName;
	private String generalPhoneNumber;
	private String generalBirthDate;

}
