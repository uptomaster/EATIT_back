package com.bapseguen.app.dto.view;

public class ItemSimpleDTO {
    private Long itemNumber;
    private String itemName;
    private int itemPrice;
    private int itemQuantity;
}