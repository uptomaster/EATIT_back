package com.bapseguen.app.dto.view;

public class OrdersList {
	private int reviewNumber;
	private int ordersNumber;
	private int businessNumber;
	private int MemberNumber;
	private int reviewRating;
	private String reviewContent;
	private String reviewCreateDate;
	private List<itemImage> files;
	private int itemPrice; 
	private int itemQuantity;
}
