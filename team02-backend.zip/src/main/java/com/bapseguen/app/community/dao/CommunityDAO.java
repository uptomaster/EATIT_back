package com.bapseguen.app.community.dao;

public class CommunityDAO {

}
