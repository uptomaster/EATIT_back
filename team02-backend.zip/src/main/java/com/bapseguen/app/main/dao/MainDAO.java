package com.bapseguen.app.main.dao;

public class MainDAO {

}
