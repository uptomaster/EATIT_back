package com.bapseguen.app.sellerMyPage.dao;

public class SellerMyPageDAO {

}
