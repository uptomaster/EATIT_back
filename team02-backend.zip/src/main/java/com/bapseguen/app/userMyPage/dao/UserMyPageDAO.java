package com.bapseguen.app.userMyPage.dao;

public class UserMyPageDAO {

}
