package com.bapseguen.app.join.dao;

public class JoinDAO {

}
