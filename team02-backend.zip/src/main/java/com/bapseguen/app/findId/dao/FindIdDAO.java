package com.bapseguen.app.findId.dao;

public class FindIdDAO {

}
