package com.bapseguen.app.headerLogin.dao;

public class HeaderLoginDAO {

}
