package com.bapseguen.app.footer.dao;

public class FooterDAO {

}
