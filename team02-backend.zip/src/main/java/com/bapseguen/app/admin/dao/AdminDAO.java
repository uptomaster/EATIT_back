package com.bapseguen.app.admin.dao;

public class AdminDAO {

}
